<footer>
    <div class="wrapper">
        CSIS270
    </div>
</footer>