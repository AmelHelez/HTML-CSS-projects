<?php

$fname = $_POST['first_name'];

var_dump($_GET);

echo '<br><br><br>';
var_dump($_POST);

echo $fname;
?>