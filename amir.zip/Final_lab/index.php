<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>University</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
    <div style="wrapper">
        <nav>
            <h1>University SSST</h1>
            <p><a href="list.php">Go to the list</a></p>
        </nav>
    </div>
</header>
<main class="wrapper">
    <div class="slikanajveca"></div>
    <div class="column">

    </div>
    <div class="column">

    </div>
    <div class="column">

    </div>
</main>
<footer>
    <div class="wrapper">
        &copy; Made by @amelez
    </div>
</footer>
</body>
</html>