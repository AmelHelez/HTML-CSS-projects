<?php
echo "Copyright @copy; 1999-" .date("Y");
?>