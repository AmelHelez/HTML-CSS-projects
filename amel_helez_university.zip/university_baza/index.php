<!doctype html>
<html>
<head>
    <title>University</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
    <div class="wrapper">

        <h1 title="SSST Logo"><a href="index.php"><img src="download.jpg" alt="university_logo"></a></h1>
        <p><a href="list.php">Go to the student list!</a></p>
    </div>
</header>
<div style="clear: both"></div>
<main class="wrapper">
    <div class="image">

    </div>

        <div class="column one">
            <h2>Our University</h2>
        </div>
    <div class="column two">
            <h2 style="color:black">The Cafeteria</h2>
        </div>
        <div class="column three">
            <h2>Winter Academy</h2>
        </div>
</main>
<div style="clear: both"></div>

<?php
include('footer.php'); ?>
</body>
</html>