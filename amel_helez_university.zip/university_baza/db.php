<?php
$conn = mysqli_connect('localhost','root','','university');

if(!$conn) {
    exit('There is some problem with connecting to the database.');
}

?>