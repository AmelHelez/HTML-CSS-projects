<head>
    <link rel="stylesheet" href="style.css">
</head>
<footer>
    <div class="wrapper">
        &copy; Made by Amel Helez, <?php echo date('d/m/Y'); ?>
    </div>
</footer>